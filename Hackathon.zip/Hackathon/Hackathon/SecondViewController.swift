//
//  SecondViewController.swift
//  Hackathon
//
//  Created by Bari Abdul, Shoaib Momin and Sufiyan Abdus Sadiq on 11/5/16.
//  Copyright © 2016 Bari Abdul. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {

    @IBOutlet weak var num1: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    @IBOutlet weak var num2: UITextField!
    @IBOutlet weak var text: UITextView!

    @IBAction func saveB(sender: UIButton) {
        let number1 = num1.text!
        let number2 = num2.text!
        let textF = text.text!
        
       func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
            if segue.identifier == "MySegueID" {
                if let destination = segue.destinationViewController as? SecondViewController {
                    destination.num1 = self.num1
                    destination.num2 = self.num2
                    destination.text = self.text
                }
            }
        }
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
        self.view.endEditing(true)
    }

}

